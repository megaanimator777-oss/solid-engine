package com.musicviz.engine;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Готовая сетка BMW E30 (конвертирована из OBJ): позиции, нормали, UV, материалы, классы. */
final class ObjCar {
    static final String[] TEX_FILES = {
        "e30_main.jpg", "e30_cabin.jpg", "e30_lights.jpg", "e30_wheel.jpg", "e30_glass.jpg",
        "suspension.jpg", "tread.jpg", "grills.jpg"};

    String[] mats;
    float[] pos, nrm, uv;
    int[] idx;
    byte[] tmat, tcls;
    int nv, nt;
    Tex[] tex = new Tex[TEX_FILES.length];

    private static ObjCar cache;

    static synchronized ObjCar get(Scene3D.Assets a) {
        if (cache != null) return cache;
        if (a == null) return null;
        try {
            ObjCar c = new ObjCar();
            c.load(a);
            cache = c;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return cache;
    }

    private void load(Scene3D.Assets a) throws IOException {
        InputStream in = a.open("e30.bin");
        byte[] all;
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            all = bo.toByteArray();
        } finally { in.close(); }
        ByteBuffer bb = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
        bb.getInt();
        int nm = bb.getInt();
        nv = bb.getInt();
        nt = bb.getInt();
        mats = new String[nm];
        for (int i = 0; i < nm; i++) {
            int l = bb.getInt();
            byte[] b = new byte[l];
            bb.get(b);
            mats[i] = new String(b, "UTF-8");
        }
        pos = new float[nv * 3]; nrm = new float[nv * 3]; uv = new float[nv * 2]; idx = new int[nt * 3];
        bb.asFloatBuffer().get(pos); bb.position(bb.position() + nv * 12);
        bb.asFloatBuffer().get(nrm); bb.position(bb.position() + nv * 12);
        bb.asFloatBuffer().get(uv); bb.position(bb.position() + nv * 8);
        bb.asIntBuffer().get(idx); bb.position(bb.position() + nt * 12);
        tmat = new byte[nt]; tcls = new byte[nt];
        bb.get(tmat); bb.get(tcls);
        for (int i = 0; i < TEX_FILES.length; i++) {
            InputStream ti = a.open(TEX_FILES[i]);
            try { tex[i] = a.decode(ti); } finally { ti.close(); }
        }
    }

    int texIndex(String mat) {
        switch (mat) {
            case "AERIALS": return 7;
            case "MATT": case "CAR_BODY_PAINT": case "SHINY_METAL": case "CALIPER": return 0;
            case "LIGHTS_GLASS": case "DISCS": case "LIGHTS_POD": case "LIGHTS_SATIN": return 2;
            case "CABIN": return 1;
            case "SUSPENSION": return 5;
            case "TARMAC_TYRE_WALL": case "TARMAC_WHEEL": return 3;
            case "TARMAC_TYRE_TREAD": return 6;
            case "WINDOW_GLASS": return 4;
            default: return 0;
        }
    }
}
