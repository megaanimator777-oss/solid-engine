package com.musicviz.engine;

/** Текстура: ARGB-пиксели, размеры — степени двойки. */
public final class Tex {
    public final int[] px;
    public final int w, h;
    public Tex(int[] px, int w, int h) { this.px = px; this.w = w; this.h = h; }
}
