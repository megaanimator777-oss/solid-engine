package com.musicviz.engine;

/** Гладкая интерполяция по неравномерным узлам (кубический Эрмит). */
final class Sp {
    static float eval(float[] xs, float[] ys, float x) {
        int n = xs.length;
        if (x <= xs[0]) return ys[0];
        if (x >= xs[n - 1]) return ys[n - 1];
        int i = 0;
        while (i < n - 2 && x > xs[i + 1]) i++;
        float h = xs[i + 1] - xs[i], t = (x - xs[i]) / h;
        float m0 = tan(xs, ys, i), m1 = tan(xs, ys, i + 1);
        float t2 = t * t, t3 = t2 * t;
        return (2*t3 - 3*t2 + 1) * ys[i] + (t3 - 2*t2 + t) * h * m0 + (-2*t3 + 3*t2) * ys[i + 1] + (t3 - t2) * h * m1;
    }
    private static float tan(float[] xs, float[] ys, int i) {
        int n = xs.length;
        if (i == 0) return (ys[1] - ys[0]) / (xs[1] - xs[0]);
        if (i == n - 1) return (ys[n - 1] - ys[n - 2]) / (xs[n - 1] - xs[n - 2]);
        return (ys[i + 1] - ys[i - 1]) / (xs[i + 1] - xs[i - 1]);
    }
}
