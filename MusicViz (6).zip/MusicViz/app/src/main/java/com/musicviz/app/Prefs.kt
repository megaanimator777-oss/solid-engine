package com.musicviz.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "musicviz"
    const val MODEL = "model"
    const val PAINT = "paint"
    const val ACCENT = "accent"
    const val SENS = "sens"
    const val BARS = "bars"
    const val SUB_ON = "sub_on"
    const val POWER = "power"
    const val MUFFLE = "muffle"
    const val GAIN = "gain"
    const val METHOD = "method"
    const val AUTOROT = "autorot"
    const val QUALITY = "quality"
    const val HEAD = "head"
    const val CABIN = "cabin"
    const val DOORS = "doors"
    const val TRUNK = "trunk"
    const val FLOOR = "floor"
    const val HOOD = "hood"
    const val FLASH = "flash"
    const val SUBLED = "subled"

    fun get(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
