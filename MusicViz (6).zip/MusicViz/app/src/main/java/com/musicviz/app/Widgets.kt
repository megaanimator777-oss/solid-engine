package com.musicviz.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.widget.RemoteViews
import com.musicviz.engine.Scene3D

/** Единая настройка сцены из сохранённых параметров (для приложения и виджета). */
object SceneConfig {
    fun apply(scene: Scene3D, p: SharedPreferences, widget: Boolean) {
        val m = p.getInt(Prefs.MODEL, 4)
        synchronized(scene) {
            if (scene.requestedModel != m) scene.setModel(m)
            scene.setPaint(p.getInt(Prefs.PAINT, 0))
            scene.setAccent(p.getInt(Prefs.ACCENT, 0xFF00B0FF.toInt()))
            scene.headlights = p.getBoolean(Prefs.HEAD, false)
            scene.cabinLight = p.getBoolean(Prefs.CABIN, false)
            scene.doorsOpen = p.getBoolean(Prefs.DOORS, false)
            scene.trunkOpen = p.getBoolean(Prefs.TRUNK, true)
            scene.hoodOpen = p.getBoolean(Prefs.HOOD, false)
            scene.showBars = if (widget) false else p.getBoolean(Prefs.BARS, false)
            scene.floorGlow = p.getBoolean(Prefs.FLOOR, false)
            scene.flashLights = p.getBoolean(Prefs.FLASH, false)
            scene.subLed = p.getBoolean(Prefs.SUBLED, true)
            scene.showGround = !widget
        }
    }
}

object Widgets {
    private fun sizePx(ctx: Context, awm: AppWidgetManager, id: Int): IntArray {
        val o = awm.getAppWidgetOptions(id)
        val d = ctx.resources.displayMetrics.density
        var w = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180) * d).toInt()
        var h = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 140) * d).toInt()
        val m = maxOf(w, h)
        if (m > 360) {
            val k = 360f / m
            w = (w * k).toInt()
            h = (h * k).toInt()
        }
        return intArrayOf(maxOf(w, 120), maxOf(h, 90))
    }

    fun ids(ctx: Context): IntArray {
        val awm = AppWidgetManager.getInstance(ctx)
        return awm.getAppWidgetIds(ComponentName(ctx, CarWidget::class.java))
    }

    fun push(ctx: Context, awm: AppWidgetManager, id: Int, scene: Scene3D) {
        val s = sizePx(ctx, awm, id)
        val w = s[0]
        val h = s[1]
        val px = IntArray(w * h)
        synchronized(scene) { scene.render(px, w, h, 2, true) }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_car)
        rv.setImageViewBitmap(R.id.img, bmp)
        val pi = PendingIntent.getActivity(
            ctx, 5, Intent(ctx, StartActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        rv.setOnClickPendingIntent(R.id.img, pi)
        awm.updateAppWidget(id, rv)
    }

    /** Один статичный кадр (когда сервис не запущен). */
    fun staticUpdate(ctx: Context, ids: IntArray) {
        if (ids.isEmpty()) return
        AssetsInit.ensure(ctx)
        val awm = AppWidgetManager.getInstance(ctx)
        val scene = Scene3D()
        SceneConfig.apply(scene, Prefs.get(ctx), true)
        val bands = FloatArray(Scene3D.BANDS)
        for (i in 0 until 40) scene.step(0.1f, 0f, bands, 1f)
        scene.pitch = 0.26f
        scene.dist = 5.0f
        for (id in ids) push(ctx, awm, id, scene)
    }
}
