package com.musicviz.app

import android.content.Context
import android.graphics.BitmapFactory
import com.musicviz.engine.Scene3D
import com.musicviz.engine.Tex
import java.io.InputStream

/** Подключает файлы приложения (3D-модель BMW и текстуры) к движку. */
object AssetsInit {
    fun ensure(ctx: Context) {
        if (Scene3D.assets != null) return
        val am = ctx.applicationContext.assets
        Scene3D.assets = object : Scene3D.Assets {
            override fun open(name: String): InputStream = am.open(name)
            override fun decode(ins: InputStream): Tex {
                val bmp = BitmapFactory.decodeStream(ins)
                val w = bmp.width
                val h = bmp.height
                val px = IntArray(w * h)
                bmp.getPixels(px, 0, w, 0, 0, w, h)
                bmp.recycle()
                return Tex(px, w, h)
            }
        }
    }
}
